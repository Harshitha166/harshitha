package com.cloudsmart;

public class App 
{
    public static void main( String[] args )
    {
		int i;

		for(i=0;i<=300;i++)
		{
			i += 4;
   		}
	 }
}
